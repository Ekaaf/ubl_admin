<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;


class Dailyvisit extends Model
{
    protected $table = 'dailyvisits';   
}
