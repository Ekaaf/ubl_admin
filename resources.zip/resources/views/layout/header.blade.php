<header id="m_header" class="m-grid__item    m-header "  m-minimize-offset="200" m-minimize-mobile-offset="200" >
	<div class="m-container m-container--fluid m-container--full-height">
		<div class="m-stack m-stack--ver m-stack--desktop">
			<!-- BEGIN: Brand -->
			<div class="m-stack__item m-brand">
				<img src="https://bdsdentist.com/assets/img/logo.png" class="img-fluid">
			</div>
			<!-- END: Brand -->
			<div class="m-stack__item m-stack__item--fluid m-header-head" id="m_header_nav">
				<div id="m_header_topbar" class="m-topbar  m-stack m-stack--ver m-stack--general">
					<div class="m-stack__item m-topbar__nav-wrapper">
						<ul class="m-topbar__nav m-nav m-nav--inline">
							
							<li id="m_quick_sidebar_toggle" class="m-nav__item" style="display: flex;">
								<a href="{{URL::to('logout')}}" class="m-nav__link m-dropdown__toggle" style="background: #843e71;color: white;width: 90px;text-align: center;height: 10px;border-radius: 10px;align-self: center;">
									Logout
								</a>
							</li>
							<!-- <li id="m_quick_sidebar_toggle" class="m-nav__item">
								<a href="#" class="m-nav__link m-dropdown__toggle">
									<span class="m-nav__link-icon">
										<i class="flaticon-grid-menu"></i>
									</span>
								</a>
							</li> -->

						</ul>

					</div>
				</div>
				<!-- END: Topbar -->
			</div>
		</div>
	</div>
</header>